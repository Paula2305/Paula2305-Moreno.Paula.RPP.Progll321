
package Zoologico;

public class AnimalRepetidoException extends RuntimeException{
    private static final String MESSAGE = "El animal ya existe";

    public AnimalRepetidoException() {
        super(MESSAGE);
    }
}
