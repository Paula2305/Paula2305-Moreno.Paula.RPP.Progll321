
package Zoologico;

public class Ave extends Animal implements Vacunable{
    private double envergaduraAlas;

    public Ave(double envergaduraAlas, String nombre, int edad) {
        super(nombre, edad);
        this.envergaduraAlas = envergaduraAlas;
    }
    
    @Override
    public void vacunar(){
        System.out.println("Vacunando ave: " + getNombre());
    }

    @Override
    public String toString() {
        return "Ave{ "+ super.toString() + ", envergaduraAlas= " + envergaduraAlas + '}';
    }
    
    
}
