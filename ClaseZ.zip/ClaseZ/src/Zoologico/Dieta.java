
package Zoologico;


public enum Dieta {
    HERBIVORO,CARNIVORO,OMNIVORO
}
