
package Zoologico;

public class Main {

    public static void main(String[] args) {
        Zoologico zoo = new Zoologico();
        
        Mamifero mamifero = new Mamifero(12.5,Dieta.CARNIVORO,"Pupi",14);
        Mamifero mamifero2 = new Mamifero(15.5,Dieta.HERBIVORO,"Pupi",14); //prueba repetir animal con los valores nombre y edad
        Reptil reptil = new Reptil("queratinosa", "ectotermia", "Paty",10);
        Ave ave = new Ave(54.7,"Condorito", 4);
        
        try{
            zoo.agregarAnimal(mamifero);
            zoo.agregarAnimal(ave);
            zoo.agregarAnimal(reptil);
            zoo.agregarAnimal(mamifero2);
        }catch(AnimalRepetidoException ex){
            System.out.println(ex.getMessage());
        }
        
        System.out.println("----------------------");
        zoo.mostrarAnimales();
        System.out.println("----------------------");
        zoo.vacunarAnimales();
    }
    
}
