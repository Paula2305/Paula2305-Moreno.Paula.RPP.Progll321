
package Zoologico;


public class Mamifero extends Animal implements Vacunable{
    private double peso;
    private Dieta dieta;

    public Mamifero(double peso, Dieta dieta, String nombre, int edad) {
        super(nombre, edad);
        this.peso = peso;
        this.dieta = dieta;
    }
    
    @Override
    public void vacunar(){
        System.out.println("Vacunando mamifero: " + getNombre());
    }
    
    @Override
    public String toString() {
        return "Mamifero { " + super.toString() + ", peso= " + peso + ", dieta= " + dieta + '}';
    }
    
    
    
}
