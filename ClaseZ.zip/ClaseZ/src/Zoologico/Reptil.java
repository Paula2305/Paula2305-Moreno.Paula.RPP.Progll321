
package Zoologico;

public class Reptil extends Animal{
    private String tipoEscama;
    private String regulacionTemperatura;

    public Reptil(String tipoEscama, String regulacionTemperatura, String nombre, int edad) {
        super(nombre, edad);
        this.tipoEscama = tipoEscama;
        this.regulacionTemperatura = regulacionTemperatura;
    }

    @Override
    public String toString() {
        return "Reptil{ "+ super.toString() + ", tipoEscama= " + tipoEscama + ", regulacionTemperatura= " + regulacionTemperatura + '}';
    }
    
}
