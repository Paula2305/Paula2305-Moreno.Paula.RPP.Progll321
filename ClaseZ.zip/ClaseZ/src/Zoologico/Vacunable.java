
package Zoologico;

public interface Vacunable {
    
    void vacunar();
}
