
package Zoologico;

import java.util.ArrayList;
import java.util.List;

public class Zoologico{
    private List<Animal> animales;

    public Zoologico() {
        this.animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal animal){
        if(animales.contains(animal)){
            throw new AnimalRepetidoException();
        }
        animales.add(animal);
    }
    
    public void mostrarAnimales(){
        for(Animal animal : animales){
            System.out.println(animal);
        }
    }
    
    public void vacunarAnimales(){
        for(Animal animal : animales){
            if(animal instanceof Vacunable vacunar){
                vacunar.vacunar();
            }
            else{
                System.out.println(animal.getNombre() + " no se puede vacunar");
            }
        }
    }
    
}
